import { TestBed } from '@angular/core/testing';

import { RecruiterInterceptor } from './recruiter.interceptor';

describe('RecruiterInterceptor', () => {
  beforeEach(() => TestBed.configureTestingModule({
    providers: [
      RecruiterInterceptor
      ]
  }));

  it('should be created', () => {
    const interceptor: RecruiterInterceptor = TestBed.inject(RecruiterInterceptor);
    expect(interceptor).toBeTruthy();
  });
});
