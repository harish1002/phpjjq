import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { url } from 'src/environments/url';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  constructor(private httpClient: HttpClient) {}
  logIn(data: any): Observable<any> {
    return this.httpClient.post(
      `${environment.api_url}${url.recruiterLogin}`,
      data
    );
  }
  applicantList(data: any): Observable<any> {
    console.log(data);
    return this.httpClient.get(
      `${environment.api_url}${url.applicants}?option[page]=${data.page}&option[limit]=${data.limit}&filter[keyword]=${data.filter}&filter[status]=${data.status}`
    );
  }
  RegisterApplicant(data: any): Observable<any> {
    return this.httpClient.post(
      `${environment.api_url}${url.RegisterApplicant}`,
      data
    );
  }
  categoryList(): Observable<any> {
    return this.httpClient.get(`${environment.api_url}${url.getCategory}`);
  }
  categoryAddUpdate(data: any): Observable<any> {
    if (data.id) {
      return this.httpClient.put(
        `${environment.api_url}${url.getCategory}/${data.id}`,
        data
      );
    } else {
      return this.httpClient.post(
        `${environment.api_url}${url.getCategory}`,
        data
      );
    }
  }
  categoryDelete(data: any): Observable<any> {
    return this.httpClient.delete(
      `${environment.api_url}${url.getCategory}/${data.id}`
    );
  }
}
