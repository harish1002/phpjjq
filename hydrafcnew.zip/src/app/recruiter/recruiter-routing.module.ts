import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '../guard/auth.guard';
import { ApplicantListComponent } from './applicant-list/applicant-list.component';
import { CompanyJobListComponent } from './company-job-list/company-job-list.component';
import { CompanyListComponent } from './company-list/company-list.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { RecruiterLoginComponent } from './recruiter-login/recruiter-login.component';
import { RecruiterComponent } from './recruiter.component';
import { UserProfileComponent } from './user-profile/user-profile.component';

const routes: Routes = [
  { path: 'login', component: RecruiterLoginComponent },
  {
    path: '',
    component: RecruiterComponent,
    children: [
      {
        path: 'dashbaord',
        component: DashboardComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'applicantlist',
        component: ApplicantListComponent,
        canActivate: [AuthGuard],
        data: { roles: [1] },
      },
      {
        path: 'companylist',
        component: CompanyListComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'jobs',
        component: CompanyJobListComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'profile/:username',
        component: UserProfileComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'master',
        loadChildren: () =>
          import('./master/master.module').then((m) => m.MasterModule),
      },
      { path: '**', redirectTo: 'dashbaord', pathMatch: 'full' },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class RecruiterRoutingModule {}
