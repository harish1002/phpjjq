import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-pages',
  templateUrl: './add-pages.component.html',
  styleUrls: ['./add-pages.component.css']
})
export class AddPagesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
