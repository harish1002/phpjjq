import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MasterRoutingModule } from './master-routing.module';
import { PagesComponent } from './pages/pages.component';
import { CategoryComponent } from './category/category.component';
import { LocationComponent } from './location/location.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddCategoryComponent } from './category/add-category/add-category.component';
import { AddPagesComponent } from './pages/add-pages/add-pages.component';
import { MaterialModule } from 'src/app/material/material.module';

@NgModule({
  declarations: [
    PagesComponent,
    CategoryComponent,
    LocationComponent,
    AddCategoryComponent,
    AddPagesComponent,
  ],
  imports: [
    CommonModule,
    MasterRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
  ],
})
export class MasterModule {}
