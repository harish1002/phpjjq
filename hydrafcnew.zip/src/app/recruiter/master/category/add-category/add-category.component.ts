import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { UserService } from 'src/app/service/user.service';
import { CategoryComponent } from '../category.component';

@Component({
  selector: 'app-add-category',
  templateUrl: './add-category.component.html',
  styleUrls: ['./add-category.component.css'],
})
export class AddCategoryComponent implements OnInit {
  addCategoryForm: any = FormGroup;
  id: any;
  formData: any = {};
  constructor(
    public dialogRef: MatDialogRef<CategoryComponent>,
    private fb: FormBuilder,
    private userService: UserService,
    private toastr: ToastrService,
    private router: Router,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit(): void {
    this.id = this.data?.initialData?.id;
    this.formData = this.data?.initialData;
    this.addCategoryForm = this.fb.group({
      title: [
        this.formData?.title,
        [Validators.required, Validators.minLength(2)],
      ],
    });
  }
  get f() {
    return this.addCategoryForm.controls;
  }

  onSubmit() {
    let data = { ...this.formData, ...this.addCategoryForm.value };
    this.data.submit = true;
    this.dialogRef.close(this.data.submit);
    this.userService.categoryAddUpdate(data).subscribe(
      (res) => {
        if (res) {
          this.toastr.success(res.data.message || res.message);
        }
      },
      (err) => {
        if (err) {
          this.toastr.error(err.error.message || err.statusText);
        }
      }
    );
  }
}
