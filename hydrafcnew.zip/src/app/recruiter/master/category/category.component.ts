import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { UserService } from 'src/app/service/user.service';
import { AddCategoryComponent } from './add-category/add-category.component';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css'],
})
export class CategoryComponent implements OnInit {
  data: any = [];
  submit: any = false;
  displayedColumns: string[] = ['Category Name', 'Action'];
  dataSource = new MatTableDataSource(this.data);
  constructor(
    public dialog: MatDialog,
    private userService: UserService,
    private toastr: ToastrService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.getCategoryList();
  }
  getCategoryList() {
    this.userService.categoryList().subscribe(
      (res) => {
        if (res) {
          this.data = res.data;
        }
      },
      (err) => {
        if (err) {
          this.toastr.error(err.error.message || err.statusText);
        }
      }
    );
  }

  editData(data: any) {
    this.openCategoryModal(data);
    console.log(data);
  }
  deleteData(data: any) {
    console.log(data);
    Swal.fire({
      title: 'Are you sure?',
      html: `Want to delete <em> ${data.title} <em> Applicant!`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#5be190',
      cancelButtonColor: '#db415b',
      confirmButtonText: 'Yes, delete it!',
    }).then(
      (result) => {
        if (result.isConfirmed) {
          this.userService.categoryDelete(data).subscribe(
            (res) => {
              if (res) {
                this.toastr.success(res.data.message || res.message);
                this.ngOnInit();
              }
            },
            (err) => {
              if (err) {
                this.toastr.error(err.error.message || err.statusText);
              }
            }
          );
        }
      },
      (dismiss: any) => {
        if (dismiss === 'cancel') {
        }
      }
    );
  }

  openCategoryModal(data: any): void {
    const dialogRef = this.dialog.open(AddCategoryComponent, {
      data: { initialData: data, submit: this.submit },
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        console.log('cxcxc');
        this.ngOnInit();
      }
    });
  }
}
