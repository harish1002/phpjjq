import {
  AfterViewInit,
  Component,
  Input,
  OnChanges,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { DeleteModalComponent } from 'src/app/modal/delete-modal/delete-modal.component';
import { UserService } from 'src/app/service/user.service';
import { environment } from 'src/environments/environment';
import { AddApplicantComponent } from './add-applicant/add-applicant.component';
import Swal from 'sweetalert2';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-applicant-list',
  templateUrl: './applicant-list.component.html',
  styleUrls: ['./applicant-list.component.css'],
})
export class ApplicantListComponent implements OnInit {
  submit:any=false;
  page: any = 1;
  limit: any = 10;
  bsModalRef: any = BsModalRef;
  data: any = [];
  meta: any;
  IMG_URL: any;
  search: any = {};
  filter: any = '';
  status_filter: any = '';
  status: any = '';
  displayedColumns: string[] = [
    'Image',
    'First Name',
    'Last Name',
    'Email',
    'Status',
    'Action',
  ];
  dataSource = new MatTableDataSource(this.data);
  @ViewChild(MatSort) sort: any = MatSort;
  @ViewChild(MatPaginator) paginator: any = MatPaginator;
  constructor(
    private userService: UserService,
    private toastr: ToastrService,
    private router: Router,
    private modalService: BsModalService,
    private loader: NgxSpinnerService,
  ) {
    this.IMG_URL = environment.api_url;
  }

  ngOnInit(): void {
    this.getApplicantList();
    this.dataSource.sort = this.sort;
    // this.dataSource.paginator = this.paginator;
    console.warn(this.dataSource);
  }
  getApplicantList() {
    let send_data: any = {
      page: this.page,
      limit: this.limit,
      filter: this.filter,
      status: this.status_filter,
    };
    this.userService.applicantList(send_data).subscribe(
      (res) => {
        if (res) {
          this.data = res.data.items;
          this.meta = res.data.meta;
        }
      },
      (err) => {
        if (err) {
          this.toastr.error(err.error.message || err.statusText);
        }
      }
    );
  }
  chnageStatus(id: any, data: any) {
    this.status = data;
    this.getApplicantList();
  }
  searchFilter(value: any) {
    this.filter = value;
    this.getApplicantList();
  }
  statusFilter(value: any) {
    this.status_filter = value;
    this.getApplicantList();
  }
  goChangeLimit(data: any) {
    this.limit = data;
    this.getApplicantList();
  }
  goChangePage(data: any) {
    this.page = data;
    this.getApplicantList();
  }
  editData(data: any) {
    this.openAddApplicantModal(data);
  }
  deleteData(data: any) {
    Swal.fire({
      title: 'Are you sure?',
      html: `Want to delete <em> ${data.firstName} ${data.lastName} <em> Applicant!`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#5be190',
      cancelButtonColor: '#db415b',
      confirmButtonText: 'Yes, delete it!',
    }).then(
      (result) => {
        if (result.isConfirmed) {
          console.log('yes');
        }
      },
      (dismiss: any) => {
        if (dismiss === 'cancel') {
        }
      }
    );
  }
  openAddApplicantModal(data: any) {
    let initialState:any={editdata:data, submit: this.submit};
    this.bsModalRef = this.modalService.show(AddApplicantComponent, {
      initialState,
      ignoreBackdropClick: true,
      keyboard: false,
    });
    this.bsModalRef.content.closeBtnName = 'Close';
    this.bsModalRef.content?.onClose.subscribe((data:any) => {
      console.log('results', data);
    })
  }
}
