import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { Subject } from 'rxjs';
import { MustMatch } from 'src/app/helper/confirm_pass';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-add-applicant',
  templateUrl: './add-applicant.component.html',
  styleUrls: ['./add-applicant.component.css'],
})
export class AddApplicantComponent implements OnInit {
  public onClose= new Subject<boolean>();
  addapplicantForm: any = FormGroup;
  editdata:any;
  id: any;
  formData: any = {};
  constructor(
    public bsModalRef: BsModalRef,
    private fb: FormBuilder,
    private userService: UserService,
    private toastr: ToastrService,
    private router: Router,
  ) {}
  ngOnInit(): void {
    this.onClose.next(false);
    this.id = this.editdata.id;
    this.formData = this.editdata;
    this.addapplicantForm = this.fb.group(
      {
        firstName: [this.formData?.firstName, [Validators.required, Validators.minLength(2)]],
        lastName: [this.formData?.lastName, [Validators.required, Validators.minLength(2)]],
        email: [this.formData?.user?.email, [Validators.required, Validators.email]],
        password: ['', [Validators.required, Validators.minLength(7)]],
        confirm_password: [''],
      },
      {
        validator: MustMatch('password', 'confirm_password'),
      }
    );
  }
  get f() {
    return this.addapplicantForm.controls;
  }

  onSubmit() {
    this.onClose.next(true);
    this.bsModalRef.hide();
    let data = { ...this.formData, ...this.addapplicantForm.value };
    data.password = btoa(data.password);
    data.file = 'abc.png';
    delete data.confirm_password;
    /* this.userService.RegisterApplicant(data).subscribe(
      (res) => {
        if (res) {
          console.log(res);
          this.toastr.success(res.data.message || res.message);
          this.router.navigate(['/recruiter/applicantlist']);
        }
      },
      (err) => {
        if (err) {
          this.toastr.error(err.error.message || err.statusText);
        }
      }
    ); */
  }
}
