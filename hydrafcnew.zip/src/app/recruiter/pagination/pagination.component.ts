import {
  Component,
  Input,
  EventEmitter,
  OnChanges,
  OnInit,
  Output,
} from '@angular/core';

@Component({
  selector: 'app-pagination',
  templateUrl: './pagination.component.html',
  styleUrls: ['./pagination.component.css'],
})
export class PaginationComponent implements OnInit {
  @Output() changeLimit = new EventEmitter<any>();
  @Output() changePage = new EventEmitter<any>();
  @Input() meta: any;
  page: number = 1;
  limit: any = '10';
  boundaryLinks: any = true;
  collectionSize: any;
  maxSize: any;
  rotate: any = true;
  ellipses: any = true;
  constructor() {}

  ngOnInit(): void {}
  goChangeLimit(data: any) {
    this.limit = data;
    this.changeLimit.emit(this.limit);
  }
  goChangePage() {
    this.changePage.emit(this.page);
  }
}
