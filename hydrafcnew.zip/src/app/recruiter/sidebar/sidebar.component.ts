import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { HeaderComponent } from '../header/header.component';
import { RecruiterComponent } from '../recruiter.component';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css'],
})
export class SidebarComponent implements OnInit {
  @Input() opened: any;
  masterOpen: any = this.router.url.indexOf('/master') > -1 ? true : false;
  userOpen: any = [
    '/recruiter/applicantlist',
    '/recruiter/companylist',
  ].includes(this.router.url)
    ? true
    : false;
  constructor(private router: Router) {}
  ngOnInit(): void {}
  clickToggleUser() {
    this.userOpen = !this.userOpen;
    this.masterOpen = false;
  }
  clickToggleMaster() {
    this.masterOpen = !this.masterOpen;
    this.userOpen = false;
  }
}
