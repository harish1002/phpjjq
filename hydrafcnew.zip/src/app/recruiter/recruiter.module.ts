import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ApplicantListComponent } from './applicant-list/applicant-list.component';
import { CompanyListComponent } from './company-list/company-list.component';
import { MasterComponent } from './master/master.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RecruiterRoutingModule } from './recruiter-routing.module';
import { JobApplicationComponent } from './job-application/job-application.component';
import { CompanyJobListComponent } from './company-job-list/company-job-list.component';
import { JobDetailsComponent } from './job-details/job-details.component';
import { RecruiterLoginComponent } from './recruiter-login/recruiter-login.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { ContactListComponent } from './user-profile/contact-list/contact-list.component';
import { EditProfileComponent } from './user-profile/edit-profile/edit-profile.component';
import { AddressListComponent } from './user-profile/address-list/address-list.component';
import { MaterialModule } from '../material/material.module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { AddApplicantComponent } from './applicant-list/add-applicant/add-applicant.component';
import { PaginationComponent } from './pagination/pagination.component';
import { NgbPaginationModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  declarations: [
    RecruiterLoginComponent,
    DashboardComponent,
    ApplicantListComponent,
    CompanyListComponent,
    MasterComponent,
    JobApplicationComponent,
    CompanyJobListComponent,
    JobDetailsComponent,
    UserProfileComponent,
    ContactListComponent,
    EditProfileComponent,
    AddressListComponent,
    AddApplicantComponent,
    PaginationComponent,
  ],
  imports: [
    CommonModule,
    RecruiterRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    FlexLayoutModule,
    NgbPaginationModule,
  ],
})
export class RecruiterModule {}
