import { MediaMatcher } from '@angular/cdk/layout';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-recruiter-login',
  templateUrl: './recruiter-login.component.html',
  styleUrls: ['./recruiter-login.component.css'],
})
export class RecruiterLoginComponent implements OnInit {
  logInForm: any = FormGroup;
  constructor(
    private fb: FormBuilder,
    private userService: UserService,
    private toastr: ToastrService,
    private router: Router
  ) {}
  ngOnInit(): void {
    this.logInForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(7)]],
    });
  }
  get f() {
    return this.logInForm.controls;
  }

  logSubmit() {
    let data = this.logInForm.value;
    data.password = btoa(data.password);
    // delete data.chk;
    this.userService.logIn(data).subscribe(
      (res) => {
        if (res) {
          localStorage.setItem('user', JSON.stringify(res.user));
          localStorage.setItem('token', res.token);
          localStorage.setItem('user_type', res.user.type);
          this.router.navigate(['/recruiter/dashboard']);
          this.toastr.success('User Login');
        }
      },
      (err) => {
        if (err) {
          this.toastr.error(err.error.message || err.statusText);
        }
      }
    );
  }
}
