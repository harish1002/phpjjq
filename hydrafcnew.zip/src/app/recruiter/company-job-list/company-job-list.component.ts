import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-company-job-list',
  templateUrl: './company-job-list.component.html',
  styleUrls: ['./company-job-list.component.css']
})
export class CompanyJobListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
