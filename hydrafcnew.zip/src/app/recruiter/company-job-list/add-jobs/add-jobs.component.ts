import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-jobs',
  templateUrl: './add-jobs.component.html',
  styleUrls: ['./add-jobs.component.css']
})
export class AddJobsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
