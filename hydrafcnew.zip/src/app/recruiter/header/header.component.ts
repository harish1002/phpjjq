import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { RecruiterComponent } from '../recruiter.component';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
export class HeaderComponent implements OnInit {
  @Output() openSidebar = new EventEmitter<boolean>();
  constructor(public toastr: ToastrService, private router: Router) {}
  ngOnInit(): void {}
  logOut() {
    localStorage.removeItem('user');
    localStorage.removeItem('token');
    localStorage.removeItem('user_type');
    this.router.navigate(['/recruiter/login']);
    this.toastr.success('User Log out');
  }
  clickToggle() {
    this.openSidebar.emit();
  }
}
