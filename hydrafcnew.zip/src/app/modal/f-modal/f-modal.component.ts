import { Component, OnInit } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-f-modal',
  templateUrl: './f-modal.component.html',
  styleUrls: ['./f-modal.component.css'],
})
export class FModalComponent implements OnInit {
  constructor(public bsModalRef: BsModalRef) {}

  ngOnInit(): void {}
}
