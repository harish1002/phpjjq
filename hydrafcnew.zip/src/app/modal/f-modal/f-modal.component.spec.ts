import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FModalComponent } from './f-modal.component';

describe('FModalComponent', () => {
  let component: FModalComponent;
  let fixture: ComponentFixture<FModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FModalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
