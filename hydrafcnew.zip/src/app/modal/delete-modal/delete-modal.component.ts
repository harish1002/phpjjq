import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-delete-modal',
  templateUrl: './delete-modal.component.html',
  styleUrls: ['./delete-modal.component.css'],
})
export class DeleteModalComponent implements OnInit {
  @Output() deleteConfirm = new EventEmitter<boolean>();
  constructor(public bsModalRef: BsModalRef) {}

  ngOnInit(): void {}
  confirmDelete() {
    this.deleteConfirm.emit(true);
  }
}
