import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  CanActivate,
  Router,
  RouterStateSnapshot,
  UrlTree,
} from '@angular/router';
import { Observable } from 'rxjs';
import { getToken, getUserObject } from '../helper/localStore';

@Injectable({
  providedIn: 'root',
})
export class AuthGuard implements CanActivate {
  constructor(private router: Router) {}
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    if (getToken() && getUserObject()) {
      let userType = getUserObject().type;
      if (route?.data?.roles && route?.data?.roles.indexOf(userType) === -1) {
        this.router.navigate(['/recruiter/dashboard']);
        return false;
      }
      return true;
    }
    this.router.navigate(['/recruiter/login']);
    return false;
  }
}
