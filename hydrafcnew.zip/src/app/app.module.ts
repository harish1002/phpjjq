import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {
  NgbModule,
  NgbPagination,
  NgbPaginationModule,
} from '@ng-bootstrap/ng-bootstrap';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RecruiterComponent } from './recruiter/recruiter.component';
import { PagesComponent } from './pages/pages.component';
import { AuthComponent } from './auth/auth.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ToastrModule } from 'ngx-toastr';
import { RecruiterInterceptor } from './recruiter.interceptor';
import { NgxSpinnerModule } from 'ngx-spinner';
import { FModalComponent } from './modal/f-modal/f-modal.component';
import { MaterialModule } from './material/material.module';
import { ModalModule } from 'ngx-bootstrap/modal';
import { HeaderComponent } from './recruiter/header/header.component';
import { FooterComponent } from './recruiter/footer/footer.component';
import { SidebarComponent } from './recruiter/sidebar/sidebar.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MAT_FORM_FIELD_DEFAULT_OPTIONS } from '@angular/material/form-field';
import { DeleteModalComponent } from './modal/delete-modal/delete-modal.component';

@NgModule({
  declarations: [
    AppComponent,
    RecruiterComponent,
    PagesComponent,
    AuthComponent,
    FModalComponent,
    DeleteModalComponent,
    HeaderComponent,
    FooterComponent,
    SidebarComponent,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    NgbModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    FormsModule,
    NgxSpinnerModule,
    FlexLayoutModule,
    NgbPaginationModule,
    ToastrModule.forRoot({
      closeButton: true,
      timeOut: 10000,
      positionClass: 'toast-top-right',
      preventDuplicates: true,
    }),
    ModalModule.forRoot(),
    MaterialModule,
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: RecruiterInterceptor, multi: true },
    {
      provide: MAT_FORM_FIELD_DEFAULT_OPTIONS,
      useValue: { appearance: 'outline' },
    },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
