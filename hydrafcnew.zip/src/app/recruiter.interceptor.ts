import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpHeaders,
} from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { catchError, finalize } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { ToastrService } from 'ngx-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import { getToken, getUserObject } from './helper/localStore';

@Injectable()
export class RecruiterInterceptor implements HttpInterceptor {
  constructor(
    private toastr: ToastrService,
    public loader: NgxSpinnerService
  ) {}
  intercept(
    request: HttpRequest<unknown>,
    next: HttpHandler
  ): Observable<HttpEvent<unknown>> {
    this.loader.show();
    if (getToken() != null) {
      const token = getToken();
      const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
      request = request.clone({ headers: headers });
    }
    return next.handle(request).pipe(
      catchError((err) => {
        if (err.status == 401) {
          //window.location.href="/recruiter/applicantlist";
          this.loader.hide();
          return throwError(err);
        }
        this.loader.hide();
        return throwError(err);
      }),
      finalize(() => this.loader.hide())
    );
  }
}
