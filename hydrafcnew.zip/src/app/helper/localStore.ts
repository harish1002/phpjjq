export function getToken() {
  return localStorage.getItem('token');
}
export function getUserObject() {
  if (localStorage.getItem('user')) {
    let data: any = localStorage.getItem('user');
    data = JSON.parse(data);
    return data;
  }
}
