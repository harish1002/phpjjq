import { Component } from '@angular/core';
import { LoaderService } from './service/loader/loader.service';
import { NgxSpinnerService } from 'ngx-spinner';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'hydrafc';
  constructor(public isLoading: NgxSpinnerService) {}

  ngOnInit(): void {}
}
